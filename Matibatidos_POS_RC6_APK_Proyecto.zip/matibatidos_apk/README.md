# Matibatidos POS — proyecto Android WebView

Este proyecto empaqueta el archivo original `Matibatidos_POS_RC6_Acode_v24.html` en una APK Android. El HTML funcional se conserva como recurso local; se incorporan los puentes Android que el propio POS invoca para exportaciones, WhatsApp, respaldos externos e impresión Bluetooth.

## Compilar desde GitHub (también desde una tablet)

1. Crea un repositorio GitHub vacío.
2. Sube **todo el contenido de este ZIP**, incluyendo la carpeta oculta `.github`.
3. En GitHub abre **Actions** → **Construir APK Matibatidos** → **Run workflow**.
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto **Matibatidos-POS-APK-debug**.
5. Extrae el artefacto ZIP y abre `app-debug.apk` en Android para instalarlo.

El flujo descarga SheetJS 0.20.3 y Chart.js 4.4.7 durante la compilación y los incorpora como archivos locales para que las exportaciones XLSX y los gráficos no dependan de esos CDN al usar la APK. La compilación necesita acceso a Internet desde GitHub Actions.

## Funciones integradas

- WebView con JavaScript, DOM Storage e IndexedDB habilitados.
- Importación de respaldos JSON mediante selector de archivos Android.
- Exportación de Excel/CSV a `Descargas/Matibatidos`.
- Apertura de WhatsApp con número y mensaje preparados.
- Envío HTTPS del respaldo JSON al endpoint configurado en el POS.
- Selección de impresora Bluetooth ya emparejada, prueba de conexión e impresión ESC/POS básica.

## Antes de usar en producción

Esta es una primera empaquetación Android del HTML RC6 adjunto, no una certificación de funcionamiento en el dispositivo. Hay que instalarla y probar en el teléfono/tablet real: iniciar sesión, crear una venta, exportar un Excel, crear/restaurar un JSON, abrir WhatsApp, enviar respaldo al endpoint real y conectar/imprimir con el modelo exacto de impresora. La impresora debe estar emparejada previamente en Ajustes Bluetooth y ser compatible con Bluetooth clásico SPP/ESC-POS.

**Importante sobre datos:** instalar una APK nueva no migra automáticamente el `localStorage`/IndexedDB de otra aplicación o navegador. Antes de cambiar la APK usada actualmente, exporta un respaldo JSON desde la aplicación actual y guárdalo fuera de ella. Después instala esta APK, restaura el JSON y verifica los datos. Conserva la APK anterior y el respaldo hasta validar todo.

La compilación generada por este flujo es `debug` (para instalación y pruebas), no una APK firmada de distribución. No contiene claves privadas de firma.
